package thanos;

public class theter {

    public static analizador analiza = new analizador();
    public static listas gameList = new listas();
    public static int x_dim = 0;
    public static int y_dim = 0;
    public static int gameLimin = 100;

    public static void main(String[] args) {
        x_dim = 12;
        y_dim = 22;
        vistaEditor n = new vistaEditor();
        n.setVisible(true);
    }
}
